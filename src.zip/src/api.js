import axios from "axios";

//const API_BASE = "http://localhost:8000"; // Change if running elsewhere
const API_BASE = process.env.REACT_APP_API_BASE || "http://localhost:8000";
const api = axios.create({
  baseURL: API_BASE,
  // You can add interceptors here for auth token if you wish
});

export default api;