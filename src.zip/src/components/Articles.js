import React from "react";
import {
  Search, RefreshCw, FileText, Edit, Eye, Share2, Save, X
} from "lucide-react";

const Articles = ({
  articles, setArticles, filters, setFilters, searchQuery, setSearchQuery,
  selectedArticles, setSelectedArticles, editingNote, setEditingNote, notes, setNotes,
  getStatusColor, getStatusIcon, handleStatusChange, categories
}) => {
  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      article.summary.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filters.category === "all" || article.category === filters.category;
    const matchesStatus = filters.status === "all" || article.status === filters.status;
    const matchesSource = filters.source === "all" || article.sourceType === filters.source;
    const matchesRelevance = article.relevanceScore >= filters.relevanceMin;
    return matchesSearch && matchesCategory && matchesStatus && matchesSource && matchesRelevance;
  });

  return (
    <div className="p-6 space-y-4">
      <div className="bg-white rounded-lg shadow p-4">
        <div className="flex flex-wrap gap-4 items-center">
          <div className="flex-1 min-w-[200px]">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search articles..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
          </div>
          <select
            value={filters.category}
            onChange={(e) => setFilters({ ...filters, category: e.target.value })}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Categories</option>
            {categories.map(cat => (
              <option key={cat.id} value={cat.name}>{cat.name}</option>
            ))}
          </select>
          <select
            value={filters.status}
            onChange={(e) => setFilters({ ...filters, status: e.target.value })}
            className="px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          >
            <option value="all">All Status</option>
            <option value="new">New</option>
            <option value="reviewed">Reviewed</option>
            <option value="shortlisted">Shortlisted</option>
            <option value="final">Final</option>
          </select>
          <button className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 flex items-center gap-2">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </button>
        </div>
      </div>
      <div className="space-y-4">
        {filteredArticles.map(article => (
          <div key={article.id} className="bg-white rounded-lg shadow hover:shadow-lg transition-shadow">
            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{article.title}</h3>
                  <div className="flex items-center gap-4 text-sm text-gray-500 mb-3">
                    <span>{article.source}</span>
                    <span>•</span>
                    <span>{article.date}</span>
                    <span>•</span>
                    <span className="text-blue-600 font-medium">Score: {article.relevanceScore}%</span>
                  </div>
                  <p className="text-gray-600 mb-3">{article.summary}</p>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {article.tags.map(tag => (
                      <span key={tag} className="px-2 py-1 bg-gray-100 text-gray-600 rounded text-sm">
                        {tag}
                      </span>
                    ))}
                  </div>
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span className="flex items-center gap-1">
                      <Eye className="w-4 h-4" /> {article.metrics.views}
                    </span>
                    <span className="flex items-center gap-1">
                      <Share2 className="w-4 h-4" /> {article.metrics.shares}
                    </span>
                    <span className="flex items-center gap-1">
                      <Save className="w-4 h-4" /> {article.metrics.saves}
                    </span>
                  </div>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-full text-sm font-medium flex items-center gap-1 ${getStatusColor(article.status)}`}>
                    {getStatusIcon(article.status)}
                    {article.status}
                  </span>
                  <select
                    value={article.status}
                    onChange={(e) => handleStatusChange(article.id, e.target.value)}
                    className="px-3 py-1 border rounded text-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="new">New</option>
                    <option value="reviewed">Reviewed</option>
                    <option value="shortlisted">Shortlisted</option>
                    <option value="final">Final</option>
                  </select>
                </div>
                <div className="flex items-center gap-2">
                  <button className="px-3 py-1 text-blue-600 hover:bg-blue-50 rounded flex items-center gap-1">
                    <FileText className="w-4 h-4" />
                    View Full
                  </button>
                  <button
                    onClick={() => setEditingNote(article.id)}
                    className="px-3 py-1 text-gray-600 hover:bg-gray-50 rounded flex items-center gap-1"
                  >
                    <Edit className="w-4 h-4" />
                    Add Note
                  </button>
                </div>
              </div>
              {article.reason && (
                <div className="mt-4 p-3 bg-yellow-50 rounded">
                  <p className="text-sm text-gray-700">
                    <span className="font-medium">Selection Reason:</span> {article.reason}
                  </p>
                </div>
              )}
              {notes[article.id] && (
                <div className="mt-4 p-3 bg-blue-50 rounded">
                  <p className="text-sm text-gray-700">
                    <span className="font-medium">Note:</span> {notes[article.id]}
                  </p>
                </div>
              )}
              {editingNote === article.id && (
                <div className="mt-4 p-3 bg-gray-50 rounded">
                  <textarea
                    className="w-full p-2 border rounded text-sm"
                    placeholder="Add a note..."
                    rows="3"
                    onBlur={(e) => {
                      if (e.target.value) {
                        setNotes({ ...notes, [article.id]: e.target.value });
                      }
                      setEditingNote(null);
                    }}
                  />
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Articles;