import React from "react";

const AddSourceModal = ({
  showAddSource, setShowAddSource, newSource, setNewSource,
  rssSources, setRssSources
}) => {
  if (!showAddSource) return null;
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg p-6 w-full max-w-md">
        <h3 className="text-lg font-semibold mb-4">Add RSS Source</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Source Name</label>
            <input
              type="text"
              placeholder="e.g., Anthropic Blog"
              value={newSource.name}
              onChange={(e) => setNewSource({ ...newSource, name: e.target.value })}
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">RSS Feed URL</label>
            <input
              type="text"
              placeholder="https://example.com/feed"
              value={newSource.url}
              onChange={(e) => setNewSource({ ...newSource, url: e.target.value })}
              className="w-full px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            />
          </div>
        </div>
        <div className="flex justify-end gap-3 mt-6">
          <button
            onClick={() => setShowAddSource(false)}
            className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
          >
            Cancel
          </button>
          <button
            onClick={() => {
              if (newSource.name && newSource.url) {
                const newId = Math.max(...rssSources.map(s => s.id)) + 1;
                setRssSources([...rssSources, {
                  id: newId,
                  name: newSource.name,
                  url: newSource.url,
                  active: true,
                  lastSync: null
                }]);
                setNewSource({ name: '', url: '', type: 'rss' });
                setShowAddSource(false);
              }
            }}
            className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
          >
            Add Source
          </button>
        </div>
      </div>
    </div>
  );
};

export default AddSourceModal;