import React, { useState, useEffect } from "react";
import {
  TrendingUp, FileText, RefreshCw, Download, Brain
} from "lucide-react";
import { AlertCircle, Clock, Star, Check } from 'lucide-react';

import Dashboard from "./components/Dashboard";
import Articles from "./components/Articles";
import Sources from "./components/Sources";
import DeckBuilder from "./components/DeckBuilder";
import AddSourceModal from "./components/AddSourceModal";

const App = () => {
  // --- Core state management ---
  const [activeTab, setActiveTab] = useState("dashboard");
  const [articles, setArticles] = useState([]);
  const [selectedArticles, setSelectedArticles] = useState([]);
  const [filters, setFilters] = useState({
    dateRange: "30days",
    category: "all",
    source: "all",
    status: "all",
    relevanceMin: 0,
  });
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddSource, setShowAddSource] = useState(false);
  const [editingNote, setEditingNote] = useState(null);
  const [notes, setNotes] = useState({});
  const [newSource, setNewSource] = useState({ name: "", url: "", type: "rss" });

  const [rssSources, setRssSources] = useState([
    { id: 1, name: "OpenAI Blog", url: "https://openai.com/blog/rss/", active: true, lastSync: "2025-07-15 08:00" },
    { id: 2, name: "Google AI Blog", url: "https://ai.googleblog.com/feeds/posts/default", active: true, lastSync: "2025-07-15 07:45" },
    { id: 3, name: "MIT Tech Review - AI", url: "https://www.technologyreview.com/topic/artificial-intelligence/feed", active: true, lastSync: "2025-07-15 07:30" },
    { id: 4, name: "Anthropic Blog", url: "https://anthropic.com/blog/rss", active: false, lastSync: "2025-07-14 18:00" }
  ]);

  const [uploadedFiles, setUploadedFiles] = useState([
    { id: 1, name: "Gartner_AI_Trends_2025.pdf", uploadDate: "2025-07-10", status: "processed", articles: 3 },
    { id: 2, name: "McKinsey_GenAI_Banking.pdf", uploadDate: "2025-07-12", status: "processing", articles: 0 },
    { id: 3, name: "Custom_Research_Report.pdf", uploadDate: "2025-07-14", status: "processed", articles: 2 },
  ]);

  useEffect(() => {
    const mockArticles = [
      {
        id: 1,
        title: "JPMorgan Chase Implements Advanced LLM for Risk Assessment",
        source: "Financial Times",
        sourceType: "rss",
        date: "2025-07-14",
        category: "AI Adoption in Finance",
        summary: "JPMorgan Chase has deployed a custom LLM model for real-time risk assessment, reducing analysis time by 60% and improving accuracy by 35%.",
        relevanceScore: 95,
        tags: ["Finance", "Risk Management", "LLM", "Enterprise AI"],
        status: "shortlisted",
        reason: "First major implementation of LLM in risk assessment by a top-tier bank.",
        metrics: { views: 245, shares: 18, saves: 32 }
      },
      {
        id: 2,
        title: "Agentic AI Revolutionizes Customer Service at Amazon",
        source: "TechCrunch",
        sourceType: "rss",
        date: "2025-07-13",
        category: "Agentic AI",
        summary: "Amazon's new agentic AI system handles complex customer queries with 90% accuracy, reducing human intervention by 70%.",
        relevanceScore: 88,
        tags: ["Agentic AI", "Customer Service", "Automation"],
        status: "new",
        reason: "",
        metrics: { views: 189, shares: 12, saves: 28 }
      },
      {
        id: 3,
        title: "Understanding Transformer Architecture: Recent Improvements",
        source: "arXiv",
        sourceType: "manual",
        date: "2025-07-12",
        category: "Tech Corner",
        summary: "Comprehensive analysis of transformer architecture improvements including Flash Attention 3.0.",
        relevanceScore: 82,
        tags: ["Technical", "Transformers", "Architecture"],
        status: "reviewed",
        reason: "Excellent technical deep-dive for Tech Corner section.",
        metrics: { views: 156, shares: 24, saves: 45 }
      },
      {
        id: 4,
        title: "Goldman Sachs Launches AI-Powered Trading Platform",
        source: "Bloomberg",
        sourceType: "paid",
        date: "2025-07-11",
        category: "AI Adoption in Finance",
        summary: "Goldman Sachs unveils 'Marcus AI', an AI trading platform with predictive analytics.",
        relevanceScore: 91,
        tags: ["Finance", "Trading", "AI Platform"],
        status: "final",
        reason: "Major competitive move in AI adoption by leading investment bank.",
        metrics: { views: 312, shares: 45, saves: 67 }
      },
      {
        id: 5,
        title: "OpenAI Announces GPT-5 with Enhanced Reasoning",
        source: "OpenAI Blog",
        sourceType: "rss",
        date: "2025-07-10",
        category: "Product Updates",
        summary: "OpenAI reveals GPT-5 with breakthrough reasoning capabilities and 10x longer context window.",
        relevanceScore: 98,
        tags: ["OpenAI", "GPT-5", "Product Launch"],
        status: "final",
        reason: "Major product announcement from leading AI company.",
        metrics: { views: 1024, shares: 234, saves: 456 }
      }
    ];
    setArticles(mockArticles);
    setSelectedArticles(mockArticles.filter(a => a.status === "final"));
  }, []);

  const categories = [
    { id: "ai-finance", name: "AI Adoption in Finance", icon: require("lucide-react").Building2 },
    { id: "use-cases", name: "Gen AI Use Cases", icon: TrendingUp },
    { id: "agentic", name: "Agentic AI", icon: require("lucide-react").Brain },
    { id: "tech-corner", name: "Tech Corner", icon: require("lucide-react").Cpu },
    { id: "products", name: "Product Updates", icon: require("lucide-react").Users }
  ];

  const getStatusColor = (status) => {
    const colors = {
      new: "bg-gray-100 text-gray-700",
      reviewed: "bg-blue-100 text-blue-700",
      shortlisted: "bg-yellow-100 text-yellow-700",
      final: "bg-green-100 text-green-700",
    };
    return colors[status] || "bg-gray-100 text-gray-700";
  };

  const getStatusIcon = (status) => {
    const icons = {
      new: <AlertCircle className="w-4 h-4" />,
      reviewed: <Clock className="w-4 h-4" />,
      shortlisted: <Star className="w-4 h-4" />,
      final: <Check className="w-4 h-4" />
    };
    return icons[status] || null;
  };

  const handleStatusChange = (articleId, newStatus) => {
    setArticles(articles.map(article =>
      article.id === articleId ? { ...article, status: newStatus } : article
    ));
    if (newStatus === "final") {
      const article = articles.find(a => a.id === articleId);
      if (article && !selectedArticles.find(a => a.id === articleId)) {
        setSelectedArticles([...selectedArticles, article]);
      }
    } else {
      setSelectedArticles(selectedArticles.filter(a => a.id !== articleId));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <Brain className="w-8 h-8 text-blue-600" />
              <h1 className="text-xl font-bold text-gray-900">
                Gen AI Research Tool
              </h1>
            </div>
            <div className="flex items-center gap-4">
              <span className="text-sm text-gray-600">Research Division</span>
              <button className="px-4 py-2 text-sm bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                Sync Now
              </button>
            </div>
          </div>
        </div>
      </header>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <nav className="flex space-x-8 mb-8 border-b">
          {[
            { id: "dashboard", label: "Dashboard", icon: TrendingUp },
            { id: "articles", label: "Articles", icon: FileText },
            { id: "sources", label: "Sources", icon: RefreshCw },
            { id: "deck-builder", label: "Deck Builder", icon: Download },
          ].map((tab) => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`pb-4 px-1 border-b-2 font-medium text-sm flex items-center gap-2 transition-colors ${
                  activeTab === tab.id
                    ? "border-blue-500 text-blue-600"
                    : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
                }`}
              >
                <Icon className="w-4 h-4" />
                {tab.label}
              </button>
            );
          })}
        </nav>
        {activeTab === "dashboard" && (
          <Dashboard
            articles={articles}
            categories={categories}
            getStatusColor={getStatusColor}
          />
        )}
        {activeTab === "articles" && (
          <Articles
            articles={articles}
            setArticles={setArticles}
            filters={filters}
            setFilters={setFilters}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            selectedArticles={selectedArticles}
            setSelectedArticles={setSelectedArticles}
            editingNote={editingNote}
            setEditingNote={setEditingNote}
            notes={notes}
            setNotes={setNotes}
            getStatusColor={getStatusColor}
            getStatusIcon={getStatusIcon}
            handleStatusChange={handleStatusChange}
            categories={categories}
          />
        )}
        {activeTab === "sources" && (
          <Sources
            rssSources={rssSources}
            setRssSources={setRssSources}
            showAddSource={showAddSource}
            setShowAddSource={setShowAddSource}
            newSource={newSource}
            setNewSource={setNewSource}
            uploadedFiles={uploadedFiles}
            setUploadedFiles={setUploadedFiles}
          />
        )}
        {activeTab === "deck-builder" && (
          <DeckBuilder
            categories={categories}
            selectedArticles={selectedArticles}
            setSelectedArticles={setSelectedArticles}
            handleStatusChange={handleStatusChange}
          />
        )}
      </div>
      <AddSourceModal
        showAddSource={showAddSource}
        setShowAddSource={setShowAddSource}
        newSource={newSource}
        setNewSource={setNewSource}
        rssSources={rssSources}
        setRssSources={setRssSources}
      />
    </div>
  );
};

export default App;