import React from "react";
import { Save, Download, X } from "lucide-react";

const DeckBuilder = ({
  categories, selectedArticles, setSelectedArticles, handleStatusChange
}) => (
  <div className="p-6 space-y-6">
    <div className="bg-white rounded-lg shadow p-6">
      <h3 className="text-lg font-semibold mb-4">Monthly Deck Structure</h3>
      <div className="space-y-4">
        {categories.map((category) => {
          const categoryArticles = selectedArticles.filter(a => a.category === category.name);
          const Icon = category.icon;
          return (
            <div key={category.id} className="border rounded-lg p-4">
              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center gap-3">
                  <Icon className="w-5 h-5 text-blue-500" />
                  <h4 className="font-medium">{category.name}</h4>
                </div>
                <span className="text-sm text-gray-500">{categoryArticles.length} articles</span>
              </div>
              {categoryArticles.length > 0 ? (
                <div className="space-y-2">
                  {categoryArticles.map(article => (
                    <div key={article.id} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                      <div className="flex-1">
                        <p className="font-medium text-sm">{article.title}</p>
                        <p className="text-xs text-gray-500">{article.source}</p>
                      </div>
                      <button
                        onClick={() => {
                          setSelectedArticles(selectedArticles.filter(a => a.id !== article.id));
                          handleStatusChange(article.id, "shortlisted");
                        }}
                        className="text-red-600 hover:bg-red-50 p-1 rounded"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-500 italic">No articles selected for this category</p>
              )}
            </div>
          );
        })}
      </div>
    </div>
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Generate Deck</h3>
        <div className="flex items-center gap-3">
          <button className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50 flex items-center gap-2">
            <Save className="w-4 h-4" />
            Save Draft
          </button>
          <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export PPT
          </button>
        </div>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="p-4 border rounded-lg">
          <h4 className="font-medium mb-2">Deck Settings</h4>
          <div className="space-y-3">
            <div>
              <label className="text-sm text-gray-600">Title</label>
              <input
                type="text"
                defaultValue="Gen AI & LLM Trends - July 2025"
                className="w-full mt-1 px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div>
              <label className="text-sm text-gray-600">Template</label>
              <select className="w-full mt-1 px-3 py-2 border rounded focus:outline-none focus:ring-2 focus:ring-blue-500">
                <option>Standard Research Template</option>
                <option>Executive Summary Template</option>
                <option>Detailed Analysis Template</option>
              </select>
            </div>
          </div>
        </div>
        <div className="p-4 border rounded-lg">
          <h4 className="font-medium mb-2">Content Options</h4>
          <div className="space-y-2">
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked className="rounded" />
              <span className="text-sm">Include executive summary</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked className="rounded" />
              <span className="text-sm">Generate article summaries</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" defaultChecked className="rounded" />
              <span className="text-sm">Add trend analysis charts</span>
            </label>
            <label className="flex items-center gap-2">
              <input type="checkbox" className="rounded" />
              <span className="text-sm">Include source citations</span>
            </label>
          </div>
        </div>
      </div>
    </div>
  </div>
);

export default DeckBuilder;